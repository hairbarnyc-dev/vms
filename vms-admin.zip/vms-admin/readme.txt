=== VMS Admin ===
Contributors: enginerds
Tags: vouchers, admin, api
Requires at least: 6.2
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later


Admin plugin to manage VMS: settings, salons, vouchers, voucher details with QR/Barcode/PDF.