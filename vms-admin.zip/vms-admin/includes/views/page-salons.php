<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="wrap vms-admin-wrap">
<h1>VMS — Salons</h1>
<div id="vms-salons">
<p><em>Loading salons…</em></p>
</div>
</div>
<?php
wp_enqueue_script('vms-salons-js', VMS_ADMIN_URL.'assets/js/salons.js', ['vms-admin-js'], VMS_ADMIN_VERSION, true);
wp_enqueue_style('vms-admin-css');