<?php
namespace VMS_Admin;


if ( ! defined('ABSPATH') ) { exit; }


class API {
public static function base(){
return rtrim(get_option(Settings::OPT_API_URL, ''), '/');
}
public static function token(){
return trim(get_option(Settings::OPT_API_TOKEN, ''));
}


public static function headers(){
$h = [
'Accept' => 'application/json',
'Content-Type' => 'application/json',
];
$token = self::token();
if ($token) { $h['Authorization'] = 'Bearer '.$token; }
return $h;
}


public static function request($method, $path, $body = null){
$url = self::base().'/'.ltrim($path, '/');
$args = [
'method' => strtoupper($method),
'headers' => self::headers(),
'timeout' => 20,
];
if ($body !== null) { $args['body'] = is_string($body) ? $body : wp_json_encode($body); }
$res = wp_remote_request($url, $args);
if (is_wp_error($res)) return $res;
$code = wp_remote_retrieve_response_code($res);
$json = json_decode(wp_remote_retrieve_body($res), true);
if ($code >= 200 && $code < 300) return $json;
return new \WP_Error('vms_api_error', 'API error', ['code'=>$code,'body'=>$json]);
}


// Convenience wrappers
public static function salons(){ return self::request('GET', 'salons'); }
public static function vouchers($query = []){
$q = $query ? ('?'.http_build_query($query)) : '';
return self::request('GET', 'vouchers'.$q);
}
public static function voucherByCode($code){ return self::request('GET', 'vouchers/code/'.rawurlencode($code)); }
public static function redeem($code, $salonId, $notes=''){ return self::request('POST', 'vouchers/'.$code.'/redeem', ['salon_id'=>(int)$salonId, 'notes'=>$notes]); }
public static function void($code, $notes=''){ return self::request('POST', 'vouchers/'.$code.'/void', ['notes'=>$notes]); }
}