(function($){
async function fetchSalons(){
const res = await $.post(VMSAdmin.ajax, { action:'vms_fetch_salons', nonce: VMSAdmin.nonce });
if (!res || !res.success) throw new Error('Failed to load salons');
return res.data;
}
function render(list){
const $root = $('#vms-salons');
if (!Array.isArray(list) || !list.length) { $root.html('<p>No salons.</p>'); return; }
const rows = list.map(s => `<tr><td>${s.id||''}</td><td>${s.name||''}</td><td>${s.city||''}</td><td>${s.region||''}</td></tr>`).join('');
$root.html(`<table class="widefat fixed striped"><thead><tr><th>ID</th><th>Name</th><th>City</th><th>Region</th></tr></thead><tbody>${rows}</tbody></table>`);
}
jQuery(async function(){ try { render(await fetchSalons()); } catch(e){ console.error(e); jQuery('#vms-salons').html('<p class="notice notice-error">Error loading salons</p>'); } });
})(jQuery);